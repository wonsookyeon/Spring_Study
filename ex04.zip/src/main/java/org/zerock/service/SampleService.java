package org.zerock.service;

public interface SampleService {
	
	public Integer doAdd(String str1, String str2) throws Exception;
	public Integer doMinus(String str1, String str2) throws Exception;
	public Integer doMul(String str1, String str2) throws Exception;
	public Integer doDiv(String str1, String str2) throws Exception;

}
