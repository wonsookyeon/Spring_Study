a = [1,2,['a','b',['life', 'is']]]
b = [4,5,6,['you','need',['hello','world']]]
c = [4000, 5200, 6300,['espresso', 'cafe latte', ['tea','green tee']]]
a.insert(0,4)
a.remove(4)
print(a)

