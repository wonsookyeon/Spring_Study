package org.zerock.service;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml"})
@Slf4j
public class SampleTxServiceImplTest {

    @Autowired
    private SampleTxService service;

    @Test
    public void test() {
        String data = "EPL 역사 최다 합작골 '47골' 마무리? 케인, 토트넘 떠날 위기...'단짝' 손흥민은 \"어떤 결정이든 존중해야\"";
        log.info("length: {}", data.getBytes().length );
        service.addData(data);

    }
}
